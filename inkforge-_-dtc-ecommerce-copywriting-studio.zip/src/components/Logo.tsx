import React from 'react';
import { motion } from 'motion/react';

interface LogoProps {
  className?: string;
  showText?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ className, showText = true }) => {
  return (
    <div className={`flex items-center gap-4 ${className}`}>
      <motion.div 
        whileHover={{ scale: 1.05 }}
        className="relative w-12 h-12 flex items-center justify-center"
      >
        {/* Premium Monogram Icon */}
        <svg 
          viewBox="0 0 48 48" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-2xl"
        >
          <defs>
            <linearGradient id="logo-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#007AFF" />
              <stop offset="100%" stopColor="#0044FF" />
            </linearGradient>
          </defs>
          
          {/* Outer Frame */}
          <rect 
            x="2" y="2" width="44" height="44" rx="12" 
            stroke="url(#logo-grad)" 
            strokeWidth="1.5"
            strokeOpacity="0.3"
          />
          
          {/* Inner Shape - Abstract 'I' and 'F' / Pen Nib */}
          <motion.path 
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 1 }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
            d="M24 12V36M24 12L32 20M24 20H30" 
            stroke="white" 
            strokeWidth="3" 
            strokeLinecap="round" 
            strokeLinejoin="round"
          />
          
          {/* Decorative Spark */}
          <motion.circle 
            cx="32" cy="12" r="2" 
            fill="#007AFF"
            animate={{ opacity: [0.4, 1, 0.4] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </svg>
      </motion.div>
      
      {showText && (
        <div className="flex flex-col">
          <span className="text-xl font-display font-bold tracking-tight text-white">
            INK<span className="text-brand-blue">FORGE</span>
          </span>
          <span className="text-[9px] font-medium tracking-[0.3em] uppercase text-white/30">
            Copywriting Studio
          </span>
        </div>
      )}
    </div>
  );
};
