/**
 * Centralized image configuration for the portfolio.
 * Replace these URLs with your own hosted images or local paths.
 */
export const IMAGES = {
  // Your professional headshot for the Hero section
  hero: "https://i.imgur.com/b3JUMPV.jpeg",
  
  // A photo of your workspace or a secondary professional shot for the About section
  about: "https://i.imgur.com/qdLuaLu.jpeg",
};
