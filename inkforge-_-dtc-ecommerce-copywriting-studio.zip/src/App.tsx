/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowRight, 
  MessageCircle, 
  Mail, 
  ExternalLink, 
  CheckCircle2, 
  TrendingUp, 
  Users, 
  Zap,
  ChevronRight,
  Menu,
  X,
  Phone,
  Linkedin,
  Globe
} from 'lucide-react';
import { useState, useEffect } from 'react';
import { cn } from './lib/utils';
import { Logo } from './components/Logo';
import { IMAGES } from './constants/images';

// --- Components ---

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Work', href: '#work' },
    { name: 'Services', href: '#services' },
    { name: 'About', href: '#about' },
    { name: 'Process', href: '#process' },
  ];

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-500 px-6 py-4",
        isScrolled ? "bg-bg-premium/80 backdrop-blur-xl border-b border-white/5 py-3" : "bg-transparent"
      )}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <a href="#">
          <Logo />
        </a>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className="text-sm font-medium text-white/60 hover:text-white transition-colors"
            >
              {link.name}
            </a>
          ))}
          <a 
            href="https://wa.me/923189441319" 
            target="_blank" 
            rel="noopener noreferrer"
            className="bg-white text-black px-5 py-2 rounded-full text-sm font-bold hover:bg-brand-blue hover:text-white transition-all duration-300"
          >
            Hire Me
          </a>
        </div>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-white"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 right-0 bg-bg-card border-b border-white/10 p-6 flex flex-col gap-4 md:hidden"
          >
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href} 
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-lg font-medium text-white/80"
              >
                {link.name}
              </a>
            ))}
            <a 
              href="https://wa.me/923189441319" 
              className="bg-brand-blue text-white p-4 rounded-xl text-center font-bold"
            >
              Contact on WhatsApp
            </a>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
};

const Hero = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: "easeOut" } }
  };

  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Decorative Elements */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 2, repeat: Infinity, repeatType: "reverse" }}
        className="absolute top-1/4 -left-20 w-96 h-96 bg-brand-blue/20 rounded-full blur-[120px]" 
      />
      <motion.div 
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 2.5, repeat: Infinity, repeatType: "reverse", delay: 0.5 }}
        className="absolute bottom-1/4 -right-20 w-96 h-96 bg-brand-blue/10 rounded-full blur-[120px]" 
      />
      
      <motion.div 
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center relative z-10"
      >
        <div>
          <motion.div variants={itemVariants} className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-bold tracking-widest uppercase text-brand-blue mb-6">
            <span className="w-2 h-2 bg-brand-blue rounded-full animate-pulse" />
            DTC eCommerce Copywriting Studio
          </motion.div>
          <motion.h1 variants={itemVariants} className="text-6xl md:text-8xl font-display font-extrabold tracking-tighter leading-[0.9] mb-8">
            Copy forged to convert. <br />
            <span className="text-brand-blue">Every</span> <br />
            <span className="italic">word.</span>
          </motion.h1>
          <motion.p variants={itemVariants} className="text-xl text-white/60 max-w-lg mb-10 leading-relaxed">
            Most product pages lose the sale in the first five seconds. INKFORGE exists to fix that. We combine deep brand research, battle-tested DTC frameworks, and obsessive attention to persuasion — to turn browsers into buyers and buyers into loyal customers.
          </motion.p>
          <motion.div variants={itemVariants} className="flex flex-col sm:flex-row gap-4">
            <a 
              href="https://wa.me/923189441319" 
              target="_blank" 
              rel="noopener noreferrer"
              className="group bg-white text-black px-8 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 hover:bg-brand-blue hover:text-white transition-all duration-300"
            >
              Contact Me
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </a>
            <a 
              href="#services" 
              className="bg-white/5 border border-white/10 text-white px-8 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 hover:bg-white/10 transition-all"
            >
              <MessageCircle className="w-5 h-5" />
              See what we offer
            </a>
          </motion.div>
        </div>

        <motion.div 
          variants={itemVariants}
          className="relative hidden lg:block"
        >
          <motion.div 
            whileHover={{ scale: 1.02 }}
            transition={{ duration: 0.5 }}
            className="aspect-square rounded-3xl overflow-hidden glass p-4"
          >
            <img 
              src={IMAGES.hero} 
              alt="INKFORGE" 
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover rounded-2xl grayscale hover:grayscale-0 transition-all duration-700"
            />
          </motion.div>
          {/* Floating Stats */}
          <motion.div 
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -top-6 -right-6 glass p-6 rounded-2xl shadow-2xl"
          >
            <div className="text-3xl font-bold text-brand-blue">+40%</div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-white/40">Avg Conversion Lift</div>
          </motion.div>
          <motion.div 
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
            className="absolute -bottom-6 -left-6 glass p-6 rounded-2xl shadow-2xl"
          >
            <div className="text-3xl font-bold text-white">$10M+</div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-white/40">Revenue Generated</div>
          </motion.div>
        </motion.div>
      </motion.div>
    </section>
  );
};

const ScrollingBanner = () => {
  const text = "100% Done-For-You Product Pages ⬥ Email Sequences ⬥ Homepages ⬥ Advertorials ⬥ Video Sales Letters ⬥ Copy Audits ⬥ Supplements ⬥ Wellness ⬥ Skincare ⬥ Devices ⬥ Fashion ⬥";
  
  return (
    <div className="py-12 bg-white/5 border-y border-white/5 overflow-hidden flex whitespace-nowrap relative">
      <motion.div 
        animate={{ x: [0, -2000] }}
        transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
        className="flex gap-12 items-center pr-12"
      >
        {[1, 2, 3, 4].map((i) => (
          <span key={i} className="text-4xl md:text-6xl font-display font-black uppercase tracking-tighter text-white/10">
            {text}
          </span>
        ))}
      </motion.div>
    </div>
  );
};

const About = () => {
  const stats = [
    { label: 'PDPs Written', value: '500+', key: 'about_stat_1' },
    { label: 'Verticals Covered', value: '80+', key: 'about_stat_2' },
    { label: 'Average ROAS Lift', value: '3x', key: 'about_stat_3' },
  ];

  return (
    <section id="about" className="py-32 bg-bg-card/50">
      <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-20 items-center">
        <motion.div 
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="order-2 md:order-1"
        >
          <h2 className="text-brand-blue font-bold tracking-widest uppercase text-sm mb-4">
            What We Do
          </h2>
          <h3 className="text-4xl md:text-5xl font-display font-bold mb-8 leading-tight">
            Every deliverable built to convert.
          </h3>
          <p className="text-lg text-white/60 mb-10 leading-relaxed">
            INKFORGE doesn't write generic copy from a brief and disappear. We embed ourselves in your brand, learn your customer inside out, and craft every word to do one specific job — move someone closer to buying.
          </p>
          <div className="grid grid-cols-3 gap-8">
            {stats.map((stat, i) => (
              <motion.div 
                key={stat.label}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 + 0.5 }}
                viewport={{ once: true }}
              >
                <div className="text-3xl font-bold text-white mb-1">
                  {stat.value}
                </div>
                <div className="text-[10px] uppercase tracking-widest text-white/40 font-bold">
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
        <motion.div 
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="order-1 md:order-2"
        >
          <div className="relative group">
            <motion.div 
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.6 }}
              className="aspect-[4/5] rounded-3xl overflow-hidden"
            >
              <img 
                src={IMAGES.about} 
                alt="Workspace" 
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700"
              />
            </motion.div>
            <div className="absolute inset-0 bg-brand-blue/10 mix-blend-overlay pointer-events-none" />
          </div>
        </motion.div>
      </div>
    </section>
  );
};

const CaseStudies = () => {
  const cases = [
    {
      category: 'Client Result — INKFORGE',
      title: '"They rewrote our product page in 4 days. Within 3 weeks, our conversion rate went from 1.8% to 3.4%. The copy was the only thing we changed."',
      problem: 'Marcus T.',
      solution: 'Founder, Supplement Brand — 7-figure DTC',
      result: '↑ 89% Conversion Lift',
      color: 'from-blue-500/20 to-transparent',
      key: 'case_1'
    },
    {
      category: '↑ 2.1x Conversion vs. Control',
      title: '"We\'d worked with three copywriters before INKFORGE. They\'re the first team who actually read our customer reviews before writing a word."',
      problem: 'Sarah K. — VP Marketing',
      solution: 'Women\'s Wellness Supplement Brand',
      result: '↑ 2.1x Conversion vs. Control',
      color: 'from-purple-500/20 to-transparent',
      key: 'case_2'
    },
    {
      category: '↑ ROAS from 1.9 → 3.6',
      title: '"Our ROAS on Meta had plateaued. We tried new creative — nothing moved. Then we rebuilt the landing page with INKFORGE\'s copy."',
      problem: 'Alex T. — Media Buyer',
      solution: 'DTC Health Device Brand',
      result: '↑ ROAS from 1.9 → 3.6',
      color: 'from-emerald-500/20 to-transparent',
      key: 'case_3'
    }
  ];

  return (
    <section id="work" className="py-32">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-8"
        >
          <div>
            <h2 className="text-brand-blue font-bold tracking-widest uppercase text-sm mb-4">
              Client Results
            </h2>
            <h3 className="text-4xl md:text-6xl font-display font-bold tracking-tighter">
              What happens when the copy actually works.
            </h3>
          </div>
          <p className="text-white/40 max-w-sm">
            Detailed breakdowns of how I've engineered massive growth for industry leaders.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {cases.map((item, i) => (
            <motion.div 
              key={item.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              whileHover={{ y: -10 }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              viewport={{ once: true }}
              className={cn(
                "group relative p-8 rounded-3xl bg-bg-card border border-white/5 hover:border-brand-blue/30 transition-all duration-500 overflow-hidden",
              )}
            >
              <div className={cn("absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-100 transition-opacity duration-500", item.color)} />
              
              <div className="relative z-10">
                <motion.div 
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  transition={{ delay: i * 0.1 + 0.3 }}
                  className="text-xs font-bold text-brand-blue uppercase tracking-widest mb-6"
                >
                  {item.category}
                </motion.div>
                <h4 className="text-2xl font-display font-bold mb-6 italic group-hover:text-brand-blue transition-colors">
                  {item.title}
                </h4>
                
                <div className="space-y-4 mb-8">
                  <div>
                    <div className="text-[10px] uppercase font-bold text-white/30 mb-1">Problem</div>
                    <p className="text-sm text-white/60">
                      {item.problem}
                    </p>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase font-bold text-white/30 mb-1">Solution</div>
                    <p className="text-sm text-white/60">
                      {item.solution}
                    </p>
                  </div>
                </div>

                <div className="pt-6 border-t border-white/5">
                  <div className="text-[10px] uppercase font-bold text-white/30 mb-1">Result</div>
                  <motion.div 
                    initial={{ scale: 0.9 }}
                    whileInView={{ scale: 1 }}
                    transition={{ type: "spring", stiffness: 100 }}
                    className="text-xl font-bold text-white"
                  >
                    {item.result}
                  </motion.div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Services = () => {
  const services = [
    {
      title: 'Product Detail Pages',
      icon: <TrendingUp className="w-6 h-6" />,
      features: ['Long-form PDPs engineered for cold traffic.', 'Full page — hero, mechanism, ingredients, social proof, FAQ, and CTA.', 'Modeled on highest-converting DTC brands.'],
      tags: ['Supplements', 'Wellness', 'Beauty', 'Devices'],
      key: 'serv_1'
    },
    {
      title: 'Homepage Copy',
      icon: <Mail className="w-6 h-6" />,
      features: ['Positions your brand and captures attention.', 'Funnels visitors toward best-converting products.', 'Strategic positioning and CRO focus.'],
      tags: ['Brand Voice', 'Positioning', 'CRO'],
      key: 'serv_2'
    },
    {
      title: 'Advertorials & Pre-Sell',
      icon: <Zap className="w-6 h-6" />,
      features: ['Warm up cold traffic before the offer.', 'Editorial-style builds belief and dismantles skepticism.', 'Pre-sells the click for higher conversion.'],
      tags: ['Native Ads', 'Meta Funnels', 'VSL Support'],
      key: 'serv_3'
    },
    {
      title: 'Video Sales Letters (VSL)',
      icon: <TrendingUp className="w-6 h-6" />,
      features: ['High-converting scripts for video ads and landing pages.', 'Psychology-driven hooks and story arcs.', 'Engineered to hold attention and drive action.'],
      tags: ['Video Ads', 'YouTube', 'Direct Response'],
      key: 'serv_7'
    },
    {
      title: 'Email Sequences',
      icon: <Users className="w-6 h-6" />,
      features: ['Welcome flows, abandon cart, post-purchase.', 'Human-centric, not branded, to maximize LTV.', 'Structured for every stage of the journey.'],
      tags: ['Klaviyo', 'Welcome Flow', 'Win-Back'],
      key: 'serv_4'
    },
    {
      title: 'Copy Templates & SOPs',
      icon: <CheckCircle2 className="w-6 h-6" />,
      features: ['Reusable, brand-trained copy templates.', 'Structured with real copy, not placeholders.', 'Scale content without starting from scratch.'],
      tags: ['Systems', 'Agencies', 'In-House Teams'],
      key: 'serv_5'
    },
    {
      title: 'Copy Audits',
      icon: <Globe className="w-6 h-6" />,
      features: ['Full teardown — headline to footer.', 'Prioritized action plan with specific rewrites.', 'Quick wins your team can ship immediately.'],
      tags: ['Conversion Audit', 'Page Review', 'Quick Wins'],
      key: 'serv_6'
    }
  ];

  return (
    <section id="services" className="py-32 bg-bg-card">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-brand-blue font-bold tracking-widest uppercase text-sm mb-4 text-center">
            What We Do
          </h2>
          <h3 className="text-4xl md:text-6xl font-display font-bold text-center mb-8 tracking-tighter">
            Every deliverable built to convert.
          </h3>
          <p className="text-lg text-white/60 text-center max-w-2xl mx-auto mb-20">
            INKFORGE doesn't write generic copy from a brief and disappear. We embed ourselves in your brand, learn your customer inside out, and craft every word to do one specific job — move someone closer to buying.
          </p>
        </motion.div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, i) => (
            <motion.div 
              key={service.title}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              whileHover={{ y: -5, backgroundColor: "rgba(255, 255, 255, 0.08)" }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
              className="p-10 rounded-3xl glass transition-all group"
            >
              <motion.div 
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.5 }}
                className="w-12 h-12 bg-brand-blue/20 rounded-xl flex items-center justify-center text-brand-blue mb-8 group-hover:scale-110 transition-transform"
              >
                {service.icon}
              </motion.div>
              <h4 className="text-2xl font-display font-bold mb-6">
                {service.title}
              </h4>
              <div className="flex flex-wrap gap-2 mb-6">
                {service.tags.map((tag, idx) => (
                  <span key={idx} className="text-[10px] font-bold uppercase tracking-widest px-2 py-1 bg-white/5 border border-white/10 rounded-md text-white/40">
                    {tag}
                  </span>
                ))}
              </div>
              <ul className="space-y-4">
                {service.features.map((f, j) => (
                  <motion.li 
                    key={f}
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 + j * 0.1 + 0.3 }}
                    viewport={{ once: true }}
                    className="flex items-start gap-3 text-sm text-white/60"
                  >
                    <div className="w-1.5 h-1.5 rounded-full bg-brand-blue mt-1.5" />
                    {f}
                  </motion.li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Process = () => {
  const steps = [
    { title: 'Deep-Dive Discovery', desc: 'Before we write a word, we study your brand, customer, competitors, and current funnel. We read reviews, analyze your best-performing pages, and identify the exact copy gaps costing you conversions.', key: 'proc_1' },
    { title: 'Strategy & Structure', desc: 'Every piece gets a blueprint before execution. We align on the angle, core mechanism, objections to address, and the specific job the copy needs to do — before a single word is written.', key: 'proc_2' },
    { title: 'Copy Execution', desc: 'Full-page copy delivered with design notes, CTA variations, and section-by-section rationale. Production-ready, annotated, and built to hand straight to your design or dev team.', key: 'proc_3' },
    { title: 'Revisions & Handoff', desc: 'Two rounds of revisions on every project. We stay engaged through handoff to ensure the copy lands exactly as written — and we\'re available once the page goes live.', key: 'proc_4' }
  ];

  return (
    <section id="process" className="py-32">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-brand-blue font-bold tracking-widest uppercase text-sm mb-4 text-center">
            The INKFORGE Method
          </h2>
          <h3 className="text-4xl md:text-6xl font-display font-bold text-center mb-24 tracking-tighter">
            A process built for brands that move fast.
          </h3>
        </motion.div>
        
        <div className="grid md:grid-cols-4 gap-4">
          {steps.map((step, i) => (
            <motion.div 
              key={step.title}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
              className="relative p-10 rounded-3xl bg-bg-card border border-white/5 group hover:bg-brand-blue transition-all duration-500"
            >
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 + 0.3 }}
                viewport={{ once: true }}
                className="text-6xl font-black text-white/5 absolute -right-2 -bottom-2 group-hover:text-white/20 transition-colors"
              >
                0{i + 1}
              </motion.div>
              <h4 className="text-xl font-bold mb-4 group-hover:text-white">
                {step.title}
              </h4>
              <p className="text-sm text-white/40 leading-relaxed group-hover:text-white/80">
                {step.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const FinalCTA = () => {
  return (
    <section className="py-32 px-6 relative overflow-hidden">
      <div className="absolute inset-0 bg-brand-blue/5 pointer-events-none" />
      <div className="max-w-4xl mx-auto text-center relative z-10">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-5xl md:text-7xl font-display font-extrabold text-white mb-8 tracking-tighter leading-tight"
        >
          Ready to Start?
        </motion.h2>
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          viewport={{ once: true }}
          className="text-xl md:text-2xl text-white/60 mb-12"
        >
          Your next best-performing page starts with one conversation. Contact me today. We'll audit your current funnel, identify the biggest copy-related revenue leaks, and map out exactly what needs to be written — no pitch, no pressure.
        </motion.p>
        <motion.a 
          href="https://wa.me/923189441319"
          target="_blank"
          rel="noopener noreferrer"
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          transition={{ delay: 0.2 }}
          viewport={{ once: true }}
          className="inline-block bg-white text-black px-12 py-6 rounded-2xl font-bold text-xl shadow-2xl shadow-white/10 hover:bg-brand-blue hover:text-white transition-all duration-300"
        >
          Contact Me
        </motion.a>
        <motion.p 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          viewport={{ once: true }}
          className="mt-8 text-xs font-bold uppercase tracking-widest text-white/20"
        >
          Limited spots per month. Currently accepting new clients for Q3 2025.
        </motion.p>
      </div>
    </section>
  );
};

const Contact = () => {
  return (
    <section id="contact" className="py-32 relative overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-brand-blue/5 rounded-full blur-[120px]" />
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-20">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-brand-blue font-bold tracking-widest uppercase text-sm mb-4">
              Ready to Start?
            </h2>
            <h3 className="text-5xl md:text-7xl font-display font-extrabold mb-8 tracking-tighter leading-tight">
              Your next best-performing page starts with one conversation.
            </h3>
            <p className="text-xl text-white/60 mb-12 max-w-md">
              Contact me today. We'll audit your current funnel, identify the biggest copy-related revenue leaks, and map out exactly what needs to be written — no pitch, no pressure.
            </p>
            
            <div className="space-y-6">
              <a href="mailto:ukhanu890890@gmail.com" className="flex items-center gap-4 group">
                <motion.div 
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  className="w-12 h-12 rounded-full glass flex items-center justify-center group-hover:bg-brand-blue transition-colors"
                >
                  <Mail className="w-5 h-5" />
                </motion.div>
                <div>
                  <div className="text-[10px] uppercase font-bold text-white/30">Email Me</div>
                  <div className="text-lg font-medium">ukhanu890890@gmail.com</div>
                </div>
              </a>
              <a href="https://wa.me/923189441319" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 group">
                <motion.div 
                  whileHover={{ scale: 1.1, rotate: -5 }}
                  className="w-12 h-12 rounded-full glass flex items-center justify-center group-hover:bg-brand-blue transition-colors"
                >
                  <Phone className="w-5 h-5" />
                </motion.div>
                <div>
                  <div className="text-[10px] uppercase font-bold text-white/30">WhatsApp</div>
                  <div className="text-lg font-medium">03189441319</div>
                </div>
              </a>

              <div className="flex gap-4 pt-4">
                <motion.a 
                  whileHover={{ y: -5 }}
                  href="https://www.linkedin.com/in/hasnain-maaz-49190b402" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex-1 glass p-4 rounded-2xl flex items-center justify-center gap-3 hover:bg-brand-blue/20 transition-all border border-white/5"
                >
                  <Linkedin className="w-5 h-5 text-brand-blue" />
                  <span className="font-bold text-sm">LinkedIn</span>
                </motion.a>
              </div>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="glass p-10 rounded-3xl"
          >
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-white/40">Name</label>
                  <input type="text" className="w-full bg-white/5 border border-white/10 rounded-xl p-4 focus:outline-none focus:border-brand-blue transition-colors" placeholder="John Doe" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-white/40">Email</label>
                  <input type="email" className="w-full bg-white/5 border border-white/10 rounded-xl p-4 focus:outline-none focus:border-brand-blue transition-colors" placeholder="john@example.com" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-white/40">Message</label>
                <textarea rows={4} className="w-full bg-white/5 border border-white/10 rounded-xl p-4 focus:outline-none focus:border-brand-blue transition-colors" placeholder="Tell me about your project..." />
              </div>
              <motion.button 
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full bg-white text-black py-5 rounded-xl font-bold text-lg hover:bg-brand-blue hover:text-white transition-all duration-300"
              >
                Send Message
              </motion.button>
              <motion.a 
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                href="https://wa.me/923189441319" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-full bg-brand-blue text-white py-5 rounded-xl font-bold text-lg flex items-center justify-center gap-2 hover:opacity-90 transition-all"
              >
                <MessageCircle className="w-6 h-6" />
                Message Me on WhatsApp
              </motion.a>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="py-12 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
        <Logo className="scale-90 origin-left" />
        <div className="text-sm text-white/40">
          © {new Date().getFullYear()} INKFORGE. All rights reserved.
        </div>
        <div className="flex gap-4">
          <a 
            href="https://www.linkedin.com/in/hasnain-maaz-49190b402" 
            target="_blank" 
            rel="noopener noreferrer"
            className="w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-brand-blue hover:text-white transition-all"
          >
            <Linkedin className="w-5 h-5" />
          </a>
          <a href="mailto:ukhanu890890@gmail.com" className="w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-white hover:text-black transition-all">
            <Mail className="w-5 h-5" />
          </a>
        </div>
      </div>
    </footer>
  );
};

const FloatingWhatsApp = () => {
  return (
    <motion.a
      href="https://wa.me/923189441319"
      target="_blank"
      rel="noopener noreferrer"
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      className="fixed bottom-8 right-8 z-[100] w-16 h-16 bg-[#25D366] rounded-full flex items-center justify-center shadow-2xl shadow-[#25D366]/40 text-white"
    >
      <MessageCircle className="w-8 h-8 fill-current" />
    </motion.a>
  );
};

// --- Main App ---

export default function App() {
  return (
    <div className="font-sans selection:bg-brand-blue selection:text-white">
      <Navbar />
      <main>
        <Hero />
        <ScrollingBanner />
        <About />
        <CaseStudies />
        <Services />
        <Process />
        <FinalCTA />
        <Contact />
      </main>
      <Footer />
      <FloatingWhatsApp />
    </div>
  );
}
